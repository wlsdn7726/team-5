package com.human.zero.dao.impl;

import org.springframework.stereotype.Repository;

import com.human.zero.dao.CakeDAO;
import com.human.zero.domain.CakeVO;
import com.human.zero.domain.OtherVO;

@Repository("cakeDAO")
public class CakeDAOImpl implements CakeDAO {

	@Override
	public void addCake(CakeVO cvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCake(CakeVO cvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCake(CakeVO cvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addOther(String kind, OtherVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateOther(String kind, OtherVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteOther(String kind, OtherVO ovo) {
		// TODO Auto-generated method stub
		
	}

}
