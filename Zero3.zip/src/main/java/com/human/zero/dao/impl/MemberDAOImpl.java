package com.human.zero.dao.impl;

import org.springframework.stereotype.Repository;

import com.human.zero.dao.MemberDAO;
import com.human.zero.domain.MemberVO;

@Repository("memberDAO")
public class MemberDAOImpl implements MemberDAO {

	@Override
	public void login(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void register(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void drop(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public MemberVO memberInfo(MemberVO mvo) {
		// TODO Auto-generated method stub
		return null;
	}

}
