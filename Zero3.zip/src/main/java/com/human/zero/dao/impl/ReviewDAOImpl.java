package com.human.zero.dao.impl;

import org.springframework.stereotype.Repository;

import com.human.zero.dao.ReviewDAO;
import com.human.zero.domain.ReviewCommentVO;
import com.human.zero.domain.ReviewVO;

@Repository("reviewDAO")
public class ReviewDAOImpl implements ReviewDAO {

	@Override
	public ReviewVO showReviewList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReviewVO showReview(ReviewVO rvo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addReview(ReviewVO rvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addReviewComment(ReviewCommentVO rvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteReview(ReviewVO rvo) {
		// TODO Auto-generated method stub
		
	}

}
