package com.human.zero.dao.impl;

import org.springframework.stereotype.Repository;

import com.human.zero.dao.StatDAO;
import com.human.zero.domain.StatVO;

@Repository("statDAO")
public class StatDAOImpl implements StatDAO {

	@Override
	public StatVO cakeStatistics() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StatVO genderStatistics() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StatVO ageStatistics() {
		// TODO Auto-generated method stub
		return null;
	}

}
