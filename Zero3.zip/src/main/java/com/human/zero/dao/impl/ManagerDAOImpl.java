package com.human.zero.dao.impl;

import org.springframework.stereotype.Repository;

import com.human.zero.dao.ManagerDAO;
import com.human.zero.domain.CakeVO;
import com.human.zero.domain.MemberVO;
import com.human.zero.domain.OtherVO;
import com.human.zero.domain.StatVO;

@Repository("managerDAO")
public class ManagerDAOImpl implements ManagerDAO {

	@Override
	public void addCake(CakeVO cvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCake(CakeVO cvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCake(CakeVO cvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addOther(String kind, OtherVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateOther(String kind, OtherVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteOther(String kind, OtherVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public StatVO cakeStat() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StatVO genderStat() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public StatVO ageStat() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addBlacklist(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delBlacklist(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

}
