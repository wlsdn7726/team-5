package com.human.zero.service.impl;

import org.springframework.stereotype.Service;

import com.human.zero.domain.OrderVO;
import com.human.zero.service.OrderService;

@Service("orderService")
public class OrderServiceImpl implements OrderService {

	@Override
	public void productSell(OrderVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void madeSell(OrderVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void expReservation(OrderVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public OrderVO orderCheck() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderVO detailCheck(OrderVO ovo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderVO productSell() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderVO madeSell() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public OrderVO expReservation() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void productSellUpdate(OrderVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void madeSellUpdate(OrderVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void expReservationUpdate(OrderVO ovo) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void orderCancel(OrderVO ovo) {
		// TODO Auto-generated method stub
		
	}

}
