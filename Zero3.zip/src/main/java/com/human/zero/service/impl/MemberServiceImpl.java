package com.human.zero.service.impl;

import org.springframework.stereotype.Service;

import com.human.zero.domain.MemberVO;
import com.human.zero.service.MemberService;

@Service("memberService")
public class MemberServiceImpl implements MemberService {

	@Override
	public void login(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void register(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}
	
	@Override
	public void drop(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public MemberVO memberInfo(MemberVO mvo) {
		// TODO Auto-generated method stub
		return null;
	}

}
