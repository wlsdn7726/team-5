package com.human.zero.service.impl;

import org.springframework.stereotype.Service;

import com.human.zero.domain.ReviewCommentVO;
import com.human.zero.domain.ReviewVO;
import com.human.zero.service.ReviewService;

@Service("reviewService")
public class ReviewServiceImpl implements ReviewService {

	@Override
	public ReviewVO showReviewList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ReviewVO showReview(ReviewVO rvo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addReview(ReviewVO rvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addReviewComment(ReviewCommentVO rvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteReview(ReviewVO rvo) {
		// TODO Auto-generated method stub
		
	}

}
