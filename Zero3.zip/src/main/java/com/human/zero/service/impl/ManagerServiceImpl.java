package com.human.zero.service.impl;

import org.springframework.stereotype.Service;

import com.human.zero.domain.CakeVO;
import com.human.zero.domain.MemberVO;
import com.human.zero.domain.OtherVO;
import com.human.zero.domain.StatVO;
import com.human.zero.service.ManagerService;

@Service("managerService")
public class ManagerServiceImpl implements ManagerService {

	@Override
	public void addCake(CakeVO cvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateCake(CakeVO cvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteCake(CakeVO cvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void addOther(String kind, OtherVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateOther(String kind, OtherVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteOther(String kind, OtherVO ovo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public StatVO cakeStat() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public StatVO ganderStat() {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public StatVO ageStat() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void addBlacklist(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delBlacklist(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

}
