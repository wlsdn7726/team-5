package com.human.zero.domain;

public class CakeVO {
	String name;
	String price;
	OtherVO other;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public OtherVO getOther() {
		return other;
	}
	public void setOther(OtherVO other) {
		this.other = other;
	}
}
